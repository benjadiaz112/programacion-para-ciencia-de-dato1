import pandas as pd

# Función para el resumen general (Total, Promedio, Min, Max)
def resumen_general(df):
    resumen = {
        "Total estudiantes": float(len(df)),
        "Promedio general": round(df["promedio"].mean(), 2),
        "Nota mínima": df["promedio"].min(),
        "Nota máxima": df["promedio"].max()
    }
    return pd.Series(resumen)

# Función para promedios por carrera
def promedio_por_carrera(df):
    return (
        df.groupby("Carrera")["promedio"]
        .mean()
        .round(2)
        .reset_index()
        .rename(columns={"promedio": "promedio_carrera"})
        .sort_values("promedio_carrera", ascending=False)
    )