import pandas as pd
import numpy as np

def limpiar_estudiantes(df):
    # Limpiamos espacios en nombres y columnas
    df.columns = df.columns.str.strip()
    df['Nombre'] = df['Nombre'].str.strip()
    df['Carrera'] = df['Carrera'].str.strip()

    # Bucle for para procesar las notas
    columnas_notas = ['Nota_1', 'Nota_2', 'Nota_3']
    for col in columnas_notas:
        # Reemplazar coma por punto y convertir a número (NR -> NaN)
        df[col] = pd.to_numeric(df[col].astype(str).str.replace(',', '.'), errors='coerce')

    # Calculamos el promedio ignorando los NaN
    df['promedio'] = df[columnas_notas].mean(axis=1).round(2)

    return df