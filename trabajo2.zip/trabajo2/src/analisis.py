﻿import pandas as pd

def resumen_datos(df):
    """Retorna total de deportistas, promedio de rendimiento y edad promedio"""
    total = len(df)
    promedio_rendimiento = df['rendimiento_score'].mean()
    edad_promedio = df['edad'].mean()
    
    return {
        "total_deportistas": total,
        "promedio_rendimiento": promedio_rendimiento,
        "edad_promedio": edad_promedio
    }

def promedio_por_deporte(df):
    """Retorna el promedio de rendimiento agrupado por disciplina"""
    # Agrupamos por deporte y calculamos la media del score [cite: 30]
    resultado = df.groupby('deporte')['rendimiento_score'].mean().reset_index()
    return resultado

def deportistas_destacados(df, umbral=7.0):
    """Filtra deportistas con rendimiento_score mayor al umbral"""
    # Filtramos según el valor solicitado en la guía [cite: 31]
    destacados = df[df['rendimiento_score'] > umbral]
    return destacados