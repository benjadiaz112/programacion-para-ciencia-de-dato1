﻿import pandas as pd
import numpy as np

def limpiar_deportistas(df):
    df = df.copy()

    # 1. Normalizar nombres de columnas (Sin usar .str para evitar el error)
    df.columns = [str(col).strip().lower() for col in df.columns]

    # 2. Normalizar la columna deporte
    if 'deporte' in df.columns:
        df['deporte'] = df['deporte'].astype(str).str.strip().str.capitalize()

    # 3. Convertir peso_kg a float
    if 'peso_kg' in df.columns:
        df['peso_kg'] = df['peso_kg'].astype(str).str.replace(',', '.', regex=False)
        df['peso_kg'] = pd.to_numeric(df['peso_kg'], errors='coerce')

    # 4. Convertir columnas numéricas
    cols_num = ['edad', 'altura_cm', 'frecuencia_cardiaca_bpm', 'horas_entrenamiento_semana', 'rendimiento_score']
    for col in cols_num:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # 5. Eliminar duplicados
    df = df.drop_duplicates()

    # 6. Eliminar outliers (IQR)
    for col in ['peso_kg', 'horas_entrenamiento_semana']:
        if col in df.columns:
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            inferior = Q1 - 1.5 * IQR
            superior = Q3 + 1.5 * IQR
            df = df[(df[col] >= inferior) & (df[col] <= superior)]

    # 7. Imputar nulos con la media
    columnas_numericas = df.select_dtypes(include=[np.number]).columns
    df[columnas_numericas] = df[columnas_numericas].fillna(df[columnas_numericas].mean())

    return df